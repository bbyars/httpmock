function get_a_variable() {
	return typeof a_variable;
}
