function hello_world(arg) {
	return "_" + arg + "_";
}
