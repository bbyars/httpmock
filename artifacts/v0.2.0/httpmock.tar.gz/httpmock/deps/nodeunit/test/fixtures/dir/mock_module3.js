exports.name = 'mock_module3';
