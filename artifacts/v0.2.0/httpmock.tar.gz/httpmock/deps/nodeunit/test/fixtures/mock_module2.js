exports.name = 'mock_module2';
