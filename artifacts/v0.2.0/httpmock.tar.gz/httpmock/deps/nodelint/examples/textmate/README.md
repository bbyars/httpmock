TextMate Reporters
------------------

These are reporter files you can integrate into your own bundles and alter as
you see fit. You'll need to write your own commands for these (see the comments
within the reporter.js files) and alter the paths to your nodelint files. For
more information see the [wiki][wiki].

If all this sounds like just too much work, feel free to download and install
the [TM bundle][bundle]. It comes packaged with nodelint and all the fun.

[wiki]: http://github.com/tav/nodelint/wiki
[bundle]: http://github.com/mkitt/nodelint.tmbundle