module.exports = require('./mime');
