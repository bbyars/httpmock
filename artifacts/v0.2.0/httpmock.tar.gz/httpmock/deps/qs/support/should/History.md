
0.0.4 / 2010-11-24 
==================

  * Added `.ok` to assert truthfulness
  * Added `.arguments`
  * Fixed double required bug. [thanks dominictarr]

0.0.3 / 2010-11-19 
==================

  * Added `true` / `false` assertions

0.0.2 / 2010-11-19 
==================

  * Added chaining support

0.0.1 / 2010-11-19 
==================

  * Initial release
