
module.exports = require('./lib/querystring');